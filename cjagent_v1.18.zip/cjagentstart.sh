JAVA_HOME=/usr/java5

CJAGENT_HOME=/home/tsmcs/cjagent

CJAGENT_NAMES=cjagent.jar

if [ $# == 0 ]
	then echo "Usage: cjagentstart [start | stop | list | version]"; exit;
fi

# csh�� ��� setenv LANG ko_KR.eucKR, AIX�� ��� ko_KR.IBM-eucKR
export LANG=ko_KR.IBM-eucKR

CJAGENT_HOME_LIST=`ls -al  | grep 'cjagent0' | awk '{print $9}'`

case "$1" in

	[Vv]ersion)
		echo "CJAgent Solution v1.0"
	;;

 [Ss]tart) 
	echo "START CJAgent Process" 
	
	case "$2" in
		[Aa]ll)
			
			for cjagent_list in $CJAGENT_HOME_LIST
			do				
				cjagent_process=`ps -ef | grep "$cjagent_list/$CJAGENT_NAMES" | grep -v grep | wc -l`
				
				if [ $cjagent_process -gt 0 ]
				
				then
				    echo "$cjagent_list CJAgent Alive."
				else
				{
					cd $CJAGENT_HOME/$cjagent_list
					nohup $JAVA_HOME/bin/java  -Dfile.encoding=MS949 -Djava.awt.headless=true -jar $CJAGENT_HOME/$cjagent_list/cjagent.jar $CJAGENT_HOME/$cjagent_list/conf/cjagent.conf > /dev/null &
					echo "$cjagent_list CJAgent Process Start-up."
				}
				fi
			done
			
			cd $CJAGENT_HOME/
		;;

		*)
			cjagent_process=`ps -ef | grep "$2/$CJAGENT_NAMES" | grep $CJAGENT_HOME | grep -v grep | wc -l`
			if [ $cjagent_process != 0 ]			
			then
			    echo "$2 CJAgent Alive."
			else
			{
				cd $CJAGENT_HOME/$2
				nohup $JAVA_HOME/bin/java  -Dfile.encoding=MS949 -Djava.awt.headless=true -jar $CJAGENT_HOME/$2/cjagent.jar $CJAGENT_HOME/$2/conf/cjagent.conf  > /dev/null &
				echo "$2 CJAgent Process Start-up."
			}
			fi
			
			cd $CJAGENT_HOME/
		;;
			
	esac
	
	;;

 [Ss]top)
	echo "STOP CJAgent Process" 
	
	case "$2" in

		[Aa]ll)
					
			for cjagent_list in $CJAGENT_HOME_LIST
			do				
				cjagent_process=`ps -ef | grep "$CJAGENT_HOME/$cjagent_list/$CJAGENT_NAMES" | grep -v grep | wc -l`
				
				if [ $cjagent_process -gt 0 ]				
				then
				{
					kill_pid=`ps -ef | grep "$CJAGENT_HOME/$cjagent_list/$CJAGENT_NAMES" | grep -v grep | awk '{print $2}'`
					kill $kill_pid;
				    echo "$cjagent_list CJAgent Process Stop."
				}
				fi
			done
		;;

		*)
			cjagent_process=`ps -ef | grep "$2/$CJAGENT_NAMES" | grep $CJAGENT_HOME | grep -v grep | wc -l`
			if [ $cjagent_process != 0 ]
			then
			{
				kill_pid=`ps -ef | grep "$2/$CJAGENT_NAMES" | grep $CJAGENT_HOME | grep -v grep | awk '{if(1 == $3) print $2}'`
				kill $kill_pid;
			    echo "$2 CJAgent Process Stop."
			}
			fi			
		;;
			
	esac
;;

 [Ll]ist)
	echo "PID	PPID	STIME		COMMAND"
	for cjagent_name1 in $CJAGENT_NAMES
	do
		ps -ef | grep "$cjagent_name1" | grep -v grep | grep -v awk | awk '{if(9==NF) printf "%s\t%s\t%s\t%s %s\n",$2,$3,$5,$8,$9; else printf "%s\t%s\t%s %4-s\t%s %s\n",$2,$3,$5,$6,$9,$10}' | sort
	done
;;

esac
