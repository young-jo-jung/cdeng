######################   INFORMIX  ######################
table.name.sms.main		      = SMS_MSG
table.name.sms.log          = SMS_MSG_LOG

table.name.mms.main         = MMS_MSG
table.name.mms.log          = MMS_MSG_LOG

table.name.msg.phone.main   = MSG_PHONE
table.name.msg.phone.log    = MSG_PHONE_OG

table.name.duplex.info.main = DUPLEX_INFO

table.name.sms.main.key     = MSGKEY
table.name.mms.main.key     = MSGKEY

sequence.name.sms.main      = SMS_MSG_SEQ
sequence.name.mms.main      = MMS_MSG_SEQ

table.sms.main = CREATE TABLE [COMPARE_TABLE_NAME] \
              ( \
                MSGKEY         SERIAL                                    NOT NULL, \
                REQDATE        DATETIME YEAR TO SECOND                   NOT NULL, \
                SERIALNUM      INTEGER,                                            \
                ID             VARCHAR(16),                                        \
                STATUS         VARCHAR(1)                  DEFAULT'1'    NOT NULL, \
                RSLT           VARCHAR(2)                  DEFAULT'00',            \
                TYPE           VARCHAR(1)                  DEFAULT'0'    NOT NULL, \
                REPCNT         INTEGER                     DEFAULT 0     NOT NULL, \
                PHONE          VARCHAR(16)                 DEFAULT''     NOT NULL, \
                CALLBACK       VARCHAR(16)                 DEFAULT''     NOT NULL, \
                RSLTDATE       DATETIME YEAR TO SECOND,                            \
                REPORTDATE     DATETIME YEAR TO SECOND,                            \
                MSG            VARCHAR(160)                              NOT NULL, \
                NET            VARCHAR(4),                                         \
                ETC1           VARCHAR(160),                                       \
                ETC2           VARCHAR(160),                                       \
                ETC3           VARCHAR(160),                                       \
                ETC4           VARCHAR(160),                                       \
                ETC5           VARCHAR(160),                                       \
                ETC6           VARCHAR(160),                                       \
                PRIMARY KEY ( MSGKEY ) CONSTRAINT PK_[COMPARE_TABLE_NAME]             \
              )

table.sms.log = CREATE TABLE [COMPARE_TABLE_NAME] \
              ( \
                MSGKEY         SERIAL                                    NOT NULL, \
                REQDATE        DATETIME YEAR TO SECOND                   NOT NULL, \
                SERIALNUM      INTEGER,                                            \
                ID             VARCHAR(16),                                        \
                STATUS         VARCHAR(1)                  DEFAULT'1'    NOT NULL, \
                RSLT           VARCHAR(2)                  DEFAULT'00',            \
                TYPE           VARCHAR(1)                  DEFAULT'0'    NOT NULL, \
                REPCNT         INTEGER                     DEFAULT 0     NOT NULL, \
                PHONE          VARCHAR(16)                 DEFAULT''     NOT NULL, \
                CALLBACK       VARCHAR(16)                 DEFAULT''     NOT NULL, \
                RSLTDATE       DATETIME YEAR TO SECOND,                            \
                REPORTDATE     DATETIME YEAR TO SECOND,                            \
                MSG            VARCHAR(160)                              NOT NULL, \
                NET            VARCHAR(4),                                         \
                ETC1           VARCHAR(160),                                       \
                ETC2           VARCHAR(160),                                       \
                ETC3           VARCHAR(160),                                       \
                ETC4           VARCHAR(160),                                       \
                ETC5           VARCHAR(160),                                       \
                ETC6           VARCHAR(160)                                        \
              )

table.mms.main = CREATE TABLE [COMPARE_TABLE_NAME] \
              ( \
                MSGKEY              SERIAL                                  NOT NULL, \
                SERIALNUM           INTEGER,                                          \
                ID                  VARCHAR(16),                                      \
                STATUS              VARCHAR(2)                DEFAULT'1'    NOT NULL, \
                PHONE               VARCHAR(16)               DEFAULT''     NOT NULL, \
                CALLBACK            VARCHAR(16)               DEFAULT''     NOT NULL, \
                TYPE                VARCHAR(2)                DEFAULT'0'    NOT NULL, \
                REPCNT              INTEGER                   DEFAULT 0     NOT NULL, \
                REQDATE             DATETIME YEAR TO SECOND                 NOT NULL, \
                SENTDATE            DATETIME YEAR TO SECOND,                          \
                RSLTDATE            DATETIME YEAR TO SECOND,                          \
                REPORTDATE          DATETIME YEAR TO SECOND,                          \
                RSLT                VARCHAR(10)                DEFAULT'00',           \
                NET                 VARCHAR(10),                                      \
                SUBJECT             VARCHAR(50)                             NOT NULL, \
                MSG                 LVARCHAR(4000),                                    \
                FILE_CNT            INTEGER                    DEFAULT 0,             \
                FILE_CNT_REAL       INTEGER                    DEFAULT 0,             \
                FILE_TYPE1          VARCHAR(1),                                       \
                FILE_PATH1          VARCHAR(200),                                     \
                FILE_TYPE2          VARCHAR(1),                                       \
                FILE_PATH2          VARCHAR(200),                                     \
                FILE_TYPE3          VARCHAR(1),                                       \
                FILE_PATH3          VARCHAR(200),                                     \
                FILE_TYPE4          VARCHAR(1),                                       \
                FILE_PATH4          VARCHAR(200),                                     \
                FILE_TYPE5          VARCHAR(1),                                       \
                FILE_PATH5          VARCHAR(200),                                     \
                MMS_FILE_NAME       VARCHAR(200),                                     \
                BAR_TYPE            VARCHAR(2),                                       \
                BAR_MERGE_FILE      INTEGER,                                          \
                BAR_VALUE           VARCHAR(200),                                     \
                BAR_SIZE_WIDTH      INTEGER,                                          \
                BAR_SIZE_HEIGHT     INTEGER,                                          \
                BAR_POSITION_X      INTEGER,                                          \
                BAR_POSITION_Y      INTEGER,                                          \
                BAR_FILE_NAME       VARCHAR(200),                                     \
                ETC1                VARCHAR(160),                                     \
                ETC2                VARCHAR(160),                                     \
                ETC3                VARCHAR(160),                                     \
                ETC4                VARCHAR(160),                                     \
                ETC5                VARCHAR(160),                                     \
                ETC6                VARCHAR(160),                                     \
                PRIMARY KEY ( MSGKEY ) CONSTRAINT PK_[COMPARE_TABLE_NAME] \
              )

table.mms.log = CREATE TABLE [COMPARE_TABLE_NAME] \
              ( \
                MSGKEY              SERIAL                                  NOT NULL, \
                SERIALNUM           INTEGER,                                          \
                ID                  VARCHAR(16),                                      \
                STATUS              VARCHAR(2)                DEFAULT'1'    NOT NULL, \
                PHONE               VARCHAR(16)               DEFAULT''     NOT NULL, \
                CALLBACK            VARCHAR(16)               DEFAULT''     NOT NULL, \
                TYPE                VARCHAR(2)                DEFAULT'0'    NOT NULL, \
                REPCNT              INTEGER                   DEFAULT 0     NOT NULL, \
                REQDATE             DATETIME YEAR TO SECOND                 NOT NULL, \
                SENTDATE            DATETIME YEAR TO SECOND,                          \
                RSLTDATE            DATETIME YEAR TO SECOND,                          \
                REPORTDATE          DATETIME YEAR TO SECOND,                          \
                RSLT                VARCHAR(10)               DEFAULT'00',            \
                NET                 VARCHAR(10),                                      \
                SUBJECT             VARCHAR(50)                             NOT NULL, \
                MSG                 LVARCHAR(4000),                                    \
                FILE_CNT            INTEGER                   DEFAULT 0,              \
                FILE_CNT_REAL       INTEGER                   DEFAULT 0,              \
                FILE_TYPE1          VARCHAR(1),                                       \
                FILE_PATH1          VARCHAR(200),                                     \
                FILE_TYPE2          VARCHAR(1),                                       \
                FILE_PATH2          VARCHAR(200),                                     \
                FILE_TYPE3          VARCHAR(1),                                       \
                FILE_PATH3          VARCHAR(200),                                     \
                FILE_TYPE4          VARCHAR(1),                                       \
                FILE_PATH4          VARCHAR(200),                                     \
                FILE_TYPE5          VARCHAR(1),                                       \
                FILE_PATH5          VARCHAR(200),                                     \
                MMS_FILE_NAME       VARCHAR(200),                                     \
                BAR_TYPE            VARCHAR(2),                                       \
                BAR_MERGE_FILE      INTEGER,                                          \
                BAR_VALUE           VARCHAR(200),                                     \
                BAR_SIZE_WIDTH      INTEGER,                                          \
                BAR_SIZE_HEIGHT     INTEGER,                                          \
                BAR_POSITION_X      INTEGER,                                          \
                BAR_POSITION_Y      INTEGER,                                          \
                BAR_FILE_NAME       VARCHAR(200),                                     \
                ETC1                VARCHAR(160),                                     \
                ETC2                VARCHAR(160),                                     \
                ETC3                VARCHAR(160),                                     \
                ETC4                VARCHAR(160),                                     \
                ETC5                VARCHAR(160),                                     \
                ETC6                VARCHAR(160)                                      \
              )

table.msg.phone.main = CREATE TABLE [COMPARE_TABLE_NAME] \
                  ( \
                    MSGTYPE           CHAR(1)                   DEFAULT 'S'  NOT NULL, \
                    MSGKEY            SERIAL                                 NOT NULL, \
                    PHONE             VARCHAR(16)                            NOT NULL, \
                    CALLBACK          VARCHAR(16)                            NOT NULL, \
                    STATUS            VARCHAR(2)                DEFAULT'1'   NOT NULL, \
                    RSLTDATE          DATETIME YEAR TO SECOND,                         \
                    REPORTDATE        DATETIME YEAR TO SECOND,                         \
                    RSLT              VARCHAR(10)               DEFAULT'00',           \
                    NET               VARCHAR(10),                                     \
                    REPLACE_CNT       INTEGER                   DEFAULT 0    NOT NULL, \
                    REPLACE_MSG       VARCHAR(200),                                   \
                    PRIMARY KEY ( MSGTYPE, MSGKEY, PHONE ) CONSTRAINT PK_[COMPARE_TABLE_NAME] \
                  )

table.msg.phone.log = CREATE TABLE [COMPARE_TABLE_NAME] \
                  ( \
                    MSGTYPE           CHAR(1)                    DEFAULT 'S'  NOT NULL, \
                    MSGKEY            SERIAL                                  NOT NULL, \
                    PHONE             VARCHAR(16)                             NOT NULL, \
                    CALLBACK          VARCHAR(16)                             NOT NULL, \
                    STATUS            VARCHAR(2)                 DEFAULT'1'   NOT NULL, \
                    RSLTDATE          DATETIME YEAR TO SECOND,                          \
                    REPORTDATE        DATETIME YEAR TO SECOND,                          \
                    RSLT              VARCHAR(10)                DEFAULT'00',           \
                    NET               VARCHAR(10),                                      \
                    REPLACE_CNT       INTEGER                    DEFAULT 0    NOT NULL, \
                    REPLACE_MSG       VARCHAR(200)                                      \
                  )

table.duplex.info.main = CREATE TABLE [COMPARE_TABLE_NAME] \
                  ( \
                    INFO_SEQ                SERIAL                                       NOT NULL, \
                    INFO_MASTER_ID          VARCHAR(10)                DEFAULT 'MASTER'  NOT NULL, \
                    INFO_MASTER_ADDRESS     VARCHAR(50),                                           \
                    INFO_MASTER_NAME        VARCHAR(50),                                           \
                    INFO_MASTER_ALIVE       CHAR(1)                    DEFAULT 'N'       NOT NULL, \
                    INFO_MASTER_ALIVEDATE   DATETIME YEAR TO SECOND,                               \
                    INFO_MASTER_DIEDATE     DATETIME YEAR TO SECOND,                               \
                    INFO_SLAVE_ID           VARCHAR(10)                DEFAULT 'SLAVE'   NOT NULL, \
                    INFO_SLAVE_ADDRESS      VARCHAR(50),                                           \
                    INFO_SLAVE_NAME         VARCHAR(50),                                           \
                    INFO_SLAVE_ALIVE        CHAR(1)                    DEFAULT 'N'       NOT NULL, \
                    INFO_SLAVE_ALIVEDATE    DATETIME YEAR TO SECOND,                               \
                    INFO_SLAVE_DIEDATE      DATETIME YEAR TO SECOND,                               \
                    PRIMARY KEY ( INFO_SEQ ) CONSTRAINT PK_[COMPARE_TABLE_NAME] \
                  )

table.main.sequence.create =
table.main.sequence.select =

table.sms.main.index1 = CREATE INDEX IDX_[COMPARE_TABLE_NAME]_1 ON [COMPARE_TABLE_NAME] ( STATUS, REQDATE )
table.sms.main.index2 = CREATE INDEX IDX_[COMPARE_TABLE_NAME]_2 ON [COMPARE_TABLE_NAME] ( PHONE )

table.mms.main.index1 = CREATE INDEX IDX_[COMPARE_TABLE_NAME]_1 ON [COMPARE_TABLE_NAME] ( STATUS, REQDATE )
table.mms.main.index2 = CREATE INDEX IDX_[COMPARE_TABLE_NAME]_2 ON [COMPARE_TABLE_NAME] ( PHONE )

table.msg.phone.main.index1 =

table.sms.log.index1 = CREATE INDEX IDX_[COMPARE_TABLE_NAME]_1 ON [COMPARE_TABLE_NAME] ( STATUS, REQDATE )
table.sms.log.index2 = CREATE INDEX IDX_[COMPARE_TABLE_NAME]_2 ON [COMPARE_TABLE_NAME] ( PHONE )

table.mms.log.index1 = CREATE INDEX IDX_[COMPARE_TABLE_NAME]_1 ON [COMPARE_TABLE_NAME] ( STATUS, REQDATE )
table.mms.log.index2 = CREATE INDEX IDX_[COMPARE_TABLE_NAME]_2 ON [COMPARE_TABLE_NAME] ( PHONE )

table.msg.phone.log.index1 =

table.name.check = SELECT tabname FROM systables WHERE upper(tabname)='[COMPARE_TABLE_NAME]'

sms.send.data = SELECT FIRST 500 \
                MSGKEY    as TR_NUM,       \
                REQDATE   as TR_SENDDATE,  \
                SERIALNUM as TR_SERIALNUM, \
                ID        as TR_ID,        \
                STATUS    as TR_SENDSTAT,  \
                TYPE      as TR_MSGTYPE,   \
                REPCNT    as TR_REPCNT,    \
                PHONE     as TR_PHONE,     \
                CALLBACK  as TR_CALLBACK,  \
                MSG       as TR_MSG        \
              FROM [COMPARE_TABLE_NAME] \
              WHERE STATUS = '[:TR_SENDSTAT]' \
                      AND REQDATE <= CURRENT \
                      AND REQDATE >= CURRENT - [:INTERVAL] UNITS HOUR \
                      [:WHERE_MULTI]

mms.send.data = SELECT FIRST 500 \
                MSGKEY, \
                SERIALNUM, \
                ID, \
                STATUS, \
                PHONE, \
                CALLBACK, \
                TYPE, \
                REPCNT, \
                REQDATE, \
                SUBJECT, \
                MSG, \
                FILE_CNT, \
                FILE_CNT_REAL, \
                FILE_TYPE1, \
                FILE_PATH1, \
                FILE_TYPE2, \
                FILE_PATH2, \
                FILE_TYPE3, \
                FILE_PATH3, \
                FILE_TYPE4, \
                FILE_PATH4, \
                FILE_TYPE5, \
                FILE_PATH5, \
                BAR_TYPE, \
                BAR_MERGE_FILE, \
                BAR_VALUE, \
                BAR_SIZE_WIDTH, \
                BAR_SIZE_HEIGHT, \
                BAR_POSITION_X, \
                BAR_POSITION_Y, \
                BAR_FILE_NAME \
              FROM [COMPARE_TABLE_NAME] \
              WHERE STATUS = '[:STATUS]' \
                      AND REQDATE <= CURRENT \
                      AND REQDATE >= CURRENT - [:INTERVAL] UNITS HOUR \
                      [:WHERE_MULTI]

msg.phone.send.data = SELECT \
                      MSGTYPE, \
                      MSGKEY, \
                      PHONE, \
                      CALLBACK, \
                      STATUS, \
                      RSLTDATE, \
                      REPORTDATE, \
                      RSLT, \
                      NET, \
                      REPLACE_CNT, \
                      REPLACE_MSG \
                    FROM [COMPARE_TABLE_NAME] \
                    WHERE MSGTYPE = '[:MSGTYPE]' AND MSGKEY = [:MSGKEY]

sms.send.data.update = UPDATE [COMPARE_TABLE_NAME] \
                    SET STATUS = '[:TR_SENDSTAT]', \
                    RSLT = '[:TR_RSLTSTAT]' \
                    WHERE MSGKEY = [:TR_NUM]

mms.send.data.update = UPDATE [COMPARE_TABLE_NAME] \
                    SET STATUS = '[:STATUS]', \
                    SENTDATE = CURRENT, \
                    RSLT = '[:RSLT]' \
                    WHERE MSGKEY = [:MSGKEY]

msg.phone.send.data.update = UPDATE [COMPARE_TABLE_NAME] \
                          SET STATUS = '[:STATUS]', \
                          RSLT = '[:RSLT]' \
                          WHERE MSGTYPE = '[:MSGTYPE]' AND MSGKEY = [:MSGKEY]

sms.recev.data.update = UPDATE [COMPARE_TABLE_NAME] \
                    SET STATUS = '[:TR_SENDSTAT]', \
                    RSLTDATE = TO_DATE( [:TR_RSLTDATE], '%Y-%m-%d %T' ), \
                    REPORTDATE = CURRENT, \
                    RSLT = '[:TR_RSLTSTAT]', \
                    NET = '[:TR_NET]' \
                    WHERE MSGKEY = [:TR_NUM]

mms.recev.data.update = UPDATE [COMPARE_TABLE_NAME] \
                    SET STATUS = '[:STATUS]', \
                    RSLTDATE = TO_DATE( [:RSLTDATE], '%Y-%m-%d %T' ), \
                    REPORTDATE = CURRENT, \
                    RSLT = '[:RSLT]', \
                    NET = '[:NET]' \
                    WHERE MSGKEY = [:MSGKEY]

msg.phone.recev.data.update = UPDATE [COMPARE_TABLE_NAME] \
                          SET STATUS = '[:STATUS]', \
                          RSLTDATE = TO_DATE( [:RSLTDATE], '%Y-%m-%d %T' ), \
                          REPORTDATE = CURRENT, \
                          RSLT = '[:RSLT]', \
                          NET = '[:NET]' \
                          WHERE MSGTYPE = '[:MSGTYPE]' AND MSGKEY = [:MSGKEY] AND PHONE = '[:PHONE]'

sms.recev.data.update2 = UPDATE [COMPARE_TABLE_NAME] \
                      SET REPCNT = REPCNT + 1 \
                      WHERE MSGKEY = [:TR_NUM]

sms.recev.data.update3 = UPDATE [COMPARE_TABLE_NAME] \
                      SET STATUS = '[:TR_SENDSTAT]', \
                      REPORTDATE = CURRENT \
                      WHERE REPCNT = PHONE

mms.recev.data.update2 = UPDATE [COMPARE_TABLE_NAME] \
                      SET REPCNT = REPCNT + 1 \
                      WHERE MSGKEY = [:MSGKEY]

mms.recev.data.update3 = UPDATE [COMPARE_TABLE_NAME] \
                      SET STATUS = '[:STATUS]', \
                      REPORTDATE = CURRENT \
                      WHERE REPCNT = PHONE

sms.log.data.batch.insert = INSERT INTO [COMPARE_LOG_TABLE_NAME] \
                      ( \
                        MSGKEY         ,\
                        REQDATE        ,\
                        SERIALNUM      ,\
                        ID             ,\
                        STATUS         ,\
                        RSLT           ,\
                        TYPE           ,\
                        REPCNT         ,\
                        PHONE          ,\
                        CALLBACK       ,\
                        RSLTDATE       ,\
                        REPORTDATE     ,\
                        MSG            ,\
                        NET            ,\
                        ETC1           ,\
                        ETC2           ,\
                        ETC3           ,\
                        ETC4           ,\
                        ETC5           ,\
                        ETC6            \
                      ) \
                      SELECT \
                        MSGKEY         ,\
                        REQDATE        ,\
                        SERIALNUM      ,\
                        ID             ,\
                        STATUS         ,\
                        RSLT           ,\
                        TYPE           ,\
                        REPCNT         ,\
                        PHONE          ,\
                        CALLBACK       ,\
                        RSLTDATE       ,\
                        REPORTDATE     ,\
                        MSG            ,\
                        NET            ,\
                        ETC1           ,\
                        ETC2           ,\
                        ETC3           ,\
                        ETC4           ,\
                        ETC5           ,\
                        ETC6            \
                      FROM [COMPARE_TABLE_NAME] \
                      WHERE STATUS = '[:TR_SENDSTAT]' AND REQDATE >= TO_DATE( '[:TR_SENDDATE]','%Y-%m-%d %T')

sms.log.data.batch.delete = DELETE FROM [COMPARE_TABLE_NAME] \
                      WHERE STATUS = '[:TR_SENDSTAT]' AND REQDATE >= TO_DATE( '[:TR_SENDDATE]','%Y-%m-%d %T')

mms.log.data.batch.insert = INSERT INTO [COMPARE_LOG_TABLE_NAME] \
                      ( \
                        MSGKEY, \
                        SERIALNUM, \
                        ID, \
                        STATUS, \
                        PHONE, \
                        CALLBACK, \
                        TYPE, \
                        REPCNT, \
                        REQDATE, \
                        SENTDATE, \
                        RSLTDATE, \
                        REPORTDATE, \
                        RSLT, \
                        NET, \
                        SUBJECT, \
                        MSG, \
                        FILE_CNT, \
                        FILE_CNT_REAL, \
                        FILE_TYPE1, \
                        FILE_PATH1, \
                        FILE_TYPE2, \
                        FILE_PATH2, \
                        FILE_TYPE3, \
                        FILE_PATH3, \
                        FILE_TYPE4, \
                        FILE_PATH4, \
                        FILE_TYPE5, \
                        FILE_PATH5, \
                        MMS_FILE_NAME, \
                        BAR_TYPE, \
                        BAR_MERGE_FILE, \
                        BAR_VALUE, \
                        BAR_SIZE_WIDTH, \
                        BAR_SIZE_HEIGHT, \
                        BAR_POSITION_X, \
                        BAR_POSITION_Y, \
                        BAR_FILE_NAME, \
                        ETC1, \
                        ETC2, \
                        ETC3, \
                        ETC4, \
                        ETC5, \
                        ETC6 \
                      ) \
                      SELECT \
                        MSGKEY, \
                        SERIALNUM, \
                        ID, \
                        STATUS, \
                        PHONE, \
                        CALLBACK, \
                        TYPE, \
                        REPCNT, \
                        REQDATE, \
                        SENTDATE, \
                        RSLTDATE, \
                        REPORTDATE, \
                        RSLT, \
                        NET, \
                        SUBJECT, \
                        MSG, \
                        FILE_CNT, \
                        FILE_CNT_REAL, \
                        FILE_TYPE1, \
                        FILE_PATH1, \
                        FILE_TYPE2, \
                        FILE_PATH2, \
                        FILE_TYPE3, \
                        FILE_PATH3, \
                        FILE_TYPE4, \
                        FILE_PATH4, \
                        FILE_TYPE5, \
                        FILE_PATH5, \
                        MMS_FILE_NAME, \
                        BAR_TYPE, \
                        BAR_MERGE_FILE, \
                        BAR_VALUE, \
                        BAR_SIZE_WIDTH, \
                        BAR_SIZE_HEIGHT, \
                        BAR_POSITION_X, \
                        BAR_POSITION_Y, \
                        BAR_FILE_NAME, \
                        ETC1, \
                        ETC2, \
                        ETC3, \
                        ETC4, \
                        ETC5, \
                        ETC6 \
                      FROM [COMPARE_TABLE_NAME] \
                      WHERE STATUS = '[:STATUS]' AND REQDATE >= TO_DATE( '[:REQDATE]','%Y-%m-%d %T')

mms.log.data.batch.delete = DELETE FROM [COMPARE_TABLE_NAME] \
                      WHERE STATUS = '[:STATUS]' AND REQDATE >= TO_DATE( '[:REQDATE]','%Y-%m-%d %T')

msg.phone.log.data.batch.insert = INSERT INTO [COMPARE_LOG_TABLE_NAME] \
                            ( \
                              MSGTYPE, \
                              MSGKEY, \
                              PHONE, \
                              CALLBACK, \
                              STATUS, \
                              RSLTDATE, \
                              REPORTDATE, \
                              RSLT, \
                              NET, \
                              REPLACE_CNT, \
                              REPLACE_MSG \
                            ) \
                            SELECT \
                              MSGTYPE, \
                              MSGKEY, \
                              PHONE, \
                              CALLBACK, \
                              STATUS, \
                              RSLTDATE, \
                              REPORTDATE, \
                              RSLT, \
                              NET, \
                              REPLACE_CNT, \
                              REPLACE_MSG \
                            FROM [COMPARE_TABLE_NAME] \
                            WHERE STATUS = '[:STATUS]'

msg.phone.log.data.batch.delete = DELETE FROM [COMPARE_TABLE_NAME] \
                            WHERE STATUS = '[:STATUS]'

sms.log.data.real.select = SELECT FIRST 500 \
                        MSGKEY  as TR_NUM, \
                        REQDATE as TR_SENDDATE \
                      FROM [COMPARE_TABLE_NAME] \
                      WHERE STATUS = '[:TR_SENDSTAT]'

sms.log.data.real.insert = INSERT INTO [COMPARE_LOG_TABLE_NAME] \
                      ( \
                        MSGKEY         ,\
                        REQDATE        ,\
                        SERIALNUM      ,\
                        ID             ,\
                        STATUS         ,\
                        RSLT           ,\
                        TYPE           ,\
                        REPCNT         ,\
                        PHONE          ,\
                        CALLBACK       ,\
                        RSLTDATE       ,\
                        REPORTDATE     ,\
                        MSG            ,\
                        NET            ,\
                        ETC1           ,\
                        ETC2           ,\
                        ETC3           ,\
                        ETC4           ,\
                        ETC5           ,\
                        ETC6            \
                      ) \
                      SELECT \
                        MSGKEY         ,\
                        REQDATE        ,\
                        SERIALNUM      ,\
                        ID             ,\
                        STATUS         ,\
                        RSLT           ,\
                        TYPE           ,\
                        REPCNT         ,\
                        PHONE          ,\
                        CALLBACK       ,\
                        RSLTDATE       ,\
                        REPORTDATE     ,\
                        MSG            ,\
                        NET            ,\
                        ETC1           ,\
                        ETC2           ,\
                        ETC3           ,\
                        ETC4           ,\
                        ETC5           ,\
                        ETC6            \
                      FROM [COMPARE_TABLE_NAME] \
                      WHERE MSGKEY = [:TR_NUM]

sms.log.data.real.delete = DELETE FROM [COMPARE_TABLE_NAME] \
                      WHERE MSGKEY = [:TR_NUM]

mms.log.data.real.select = SELECT FIRST 500 \
                        MSGKEY, \
                        REQDATE \
                      FROM [COMPARE_TABLE_NAME] \
                      WHERE STATUS = '[:STATUS]'

mms.log.data.real.insert = INSERT INTO [COMPARE_LOG_TABLE_NAME] \
                      ( \
                        MSGKEY, \
                        SERIALNUM, \
                        ID, \
                        STATUS, \
                        PHONE, \
                        CALLBACK, \
                        TYPE, \
                        REPCNT, \
                        REQDATE, \
                        SENTDATE, \
                        RSLTDATE, \
                        REPORTDATE, \
                        RSLT, \
                        NET, \
                        SUBJECT, \
                        MSG, \
                        FILE_CNT, \
                        FILE_CNT_REAL, \
                        FILE_TYPE1, \
                        FILE_PATH1, \
                        FILE_TYPE2, \
                        FILE_PATH2, \
                        FILE_TYPE3, \
                        FILE_PATH3, \
                        FILE_TYPE4, \
                        FILE_PATH4, \
                        FILE_TYPE5, \
                        FILE_PATH5, \
                        MMS_FILE_NAME, \
                        BAR_TYPE, \
                        BAR_MERGE_FILE, \
                        BAR_VALUE, \
                        BAR_SIZE_WIDTH, \
                        BAR_SIZE_HEIGHT, \
                        BAR_POSITION_X, \
                        BAR_POSITION_Y, \
                        BAR_FILE_NAME, \
                        ETC1, \
                        ETC2, \
                        ETC3, \
                        ETC4, \
                        ETC5, \
                        ETC6 \
                      ) \
                      SELECT \
                        MSGKEY, \
                        SERIALNUM, \
                        ID, \
                        STATUS, \
                        PHONE, \
                        CALLBACK, \
                        TYPE, \
                        REPCNT, \
                        REQDATE, \
                        SENTDATE, \
                        RSLTDATE, \
                        REPORTDATE, \
                        RSLT, \
                        NET, \
                        SUBJECT, \
                        MSG, \
                        FILE_CNT, \
                        FILE_CNT_REAL, \
                        FILE_TYPE1, \
                        FILE_PATH1, \
                        FILE_TYPE2, \
                        FILE_PATH2, \
                        FILE_TYPE3, \
                        FILE_PATH3, \
                        FILE_TYPE4, \
                        FILE_PATH4, \
                        FILE_TYPE5, \
                        FILE_PATH5, \
                        MMS_FILE_NAME, \
                        BAR_TYPE, \
                        BAR_MERGE_FILE, \
                        BAR_VALUE, \
                        BAR_SIZE_WIDTH, \
                        BAR_SIZE_HEIGHT, \
                        BAR_POSITION_X, \
                        BAR_POSITION_Y, \
                        BAR_FILE_NAME, \
                        ETC1, \
                        ETC2, \
                        ETC3, \
                        ETC4, \
                        ETC5, \
                        ETC6 \
                      FROM [COMPARE_TABLE_NAME] \
                      WHERE MSGKEY = [:MSGKEY]

mms.log.data.real.delete = DELETE FROM [COMPARE_TABLE_NAME] \
                      WHERE MSGKEY = [:MSGKEY]

msg.phone.log.data.real.select = SELECT FIRST 500 \
                            MSGTYPE, \
                            MSGKEY, \
                            PHONE, \
                            CALLBACK, \
                            STATUS, \
                            RSLTDATE, \
                            REPORTDATE, \
                            RSLT, \
                            NET, \
                            REPLACE_CNT, \
                            REPLACE_MSG \
                          FROM [COMPARE_TABLE_NAME] \
                          WHERE STATUS = '[:STATUS]'

msg.phone.log.data.real.insert = INSERT INTO [COMPARE_LOG_TABLE_NAME] \
                          ( \
                            MSGTYPE, \
                            MSGKEY, \
                            PHONE, \
                            CALLBACK, \
                            STATUS, \
                            RSLTDATE, \
                            REPORTDATE, \
                            RSLT, \
                            NET, \
                            REPLACE_CNT, \
                            REPLACE_MSG \
                          ) \
                          SELECT \
                            MSGTYPE, \
                            MSGKEY, \
                            PHONE, \
                            CALLBACK, \
                            STATUS, \
                            RSLTDATE, \
                            REPORTDATE, \
                            RSLT, \
                            NET, \
                            REPLACE_CNT, \
                            REPLACE_MSG \
                          FROM [COMPARE_TABLE_NAME] \
                          WHERE MSGTYPE = '[:MSGTYPE]' AND MSGKEY = [:MSGKEY] AND PHONE = '[:PHONE]'

msg.phone.log.data.real.delete = DELETE FROM [COMPARE_TABLE_NAME] \
                          WHERE MSGTYPE = '[:MSGTYPE]' AND MSGKEY = [:MSGKEY] AND PHONE = '[:PHONE]'

sms.log.data.timeout.insert = INSERT INTO [COMPARE_LOG_TABLE_NAME] \
                      ( \
                        MSGKEY         ,\
                        REQDATE        ,\
                        SERIALNUM      ,\
                        ID             ,\
                        STATUS         ,\
                        RSLT           ,\
                        TYPE           ,\
                        REPCNT         ,\
                        PHONE          ,\
                        CALLBACK       ,\
                        RSLTDATE       ,\
                        REPORTDATE     ,\
                        MSG            ,\
                        NET            ,\
                        ETC1           ,\
                        ETC2           ,\
                        ETC3           ,\
                        ETC4           ,\
                        ETC5           ,\
                        ETC6            \
                      ) \
                      SELECT \
                        MSGKEY         ,\
                        REQDATE        ,\
                        SERIALNUM      ,\
                        ID             ,\
                        STATUS         ,\
                        RSLT           ,\
                        TYPE           ,\
                        REPCNT         ,\
                        PHONE          ,\
                        CALLBACK       ,\
                        RSLTDATE       ,\
                        REPORTDATE     ,\
                        MSG            ,\
                        NET            ,\
                        ETC1           ,\
                        ETC2           ,\
                        ETC3           ,\
                        ETC4           ,\
                        ETC5           ,\
                        ETC6            \
                      FROM [COMPARE_TABLE_NAME] \
                      WHERE STATUS = '[:TR_SENDSTAT]' AND REQDATE <= TO_DATE( '[:TR_SENDDATE]','%Y-%m-%d %T')

sms.log.data.timeout.delete = DELETE FROM [COMPARE_TABLE_NAME] \
                      WHERE STATUS = '[:TR_SENDSTAT]' AND REQDATE <= TO_DATE( '[:TR_SENDDATE]','%Y-%m-%d %T')

mms.log.data.timeout.insert = INSERT INTO [COMPARE_LOG_TABLE_NAME] \
                      ( \
                        MSGKEY, \
                        SERIALNUM, \
                        ID, \
                        STATUS, \
                        PHONE, \
                        CALLBACK, \
                        TYPE, \
                        REPCNT, \
                        REQDATE, \
                        SENTDATE, \
                        RSLTDATE, \
                        REPORTDATE, \
                        RSLT, \
                        NET, \
                        SUBJECT, \
                        MSG, \
                        FILE_CNT, \
                        FILE_CNT_REAL, \
                        FILE_TYPE1, \
                        FILE_PATH1, \
                        FILE_TYPE2, \
                        FILE_PATH2, \
                        FILE_TYPE3, \
                        FILE_PATH3, \
                        FILE_TYPE4, \
                        FILE_PATH4, \
                        FILE_TYPE5, \
                        FILE_PATH5, \
                        MMS_FILE_NAME, \
                        BAR_TYPE, \
                        BAR_MERGE_FILE, \
                        BAR_VALUE, \
                        BAR_SIZE_WIDTH, \
                        BAR_SIZE_HEIGHT, \
                        BAR_POSITION_X, \
                        BAR_POSITION_Y, \
                        BAR_FILE_NAME, \
                        ETC1, \
                        ETC2, \
                        ETC3, \
                        ETC4, \
                        ETC5, \
                        ETC6 \
                      ) \
                      SELECT \
                        MSGKEY, \
                        SERIALNUM, \
                        ID, \
                        STATUS, \
                        PHONE, \
                        CALLBACK, \
                        TYPE, \
                        REPCNT, \
                        REQDATE, \
                        SENTDATE, \
                        RSLTDATE, \
                        REPORTDATE, \
                        RSLT, \
                        NET, \
                        SUBJECT, \
                        MSG, \
                        FILE_CNT, \
                        FILE_CNT_REAL, \
                        FILE_TYPE1, \
                        FILE_PATH1, \
                        FILE_TYPE2, \
                        FILE_PATH2, \
                        FILE_TYPE3, \
                        FILE_PATH3, \
                        FILE_TYPE4, \
                        FILE_PATH4, \
                        FILE_TYPE5, \
                        FILE_PATH5, \
                        MMS_FILE_NAME, \
                        BAR_TYPE, \
                        BAR_MERGE_FILE, \
                        BAR_VALUE, \
                        BAR_SIZE_WIDTH, \
                        BAR_SIZE_HEIGHT, \
                        BAR_POSITION_X, \
                        BAR_POSITION_Y, \
                        BAR_FILE_NAME, \
                        ETC1, \
                        ETC2, \
                        ETC3, \
                        ETC4, \
                        ETC5, \
                        ETC6 \
                      FROM [COMPARE_TABLE_NAME] \
                      WHERE STATUS = '[:STATUS]' AND REQDATE <= TO_DATE( '[:REQDATE]','%Y-%m-%d %T')

mms.log.data.timeout.delete = DELETE FROM [COMPARE_TABLE_NAME] \
                      WHERE STATUS = '[:STATUS]' AND REQDATE <= TO_DATE( '[:REQDATE]','%Y-%m-%d %T')

