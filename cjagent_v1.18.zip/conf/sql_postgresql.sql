######################   POSTGRESQL  ######################
table.name.sms.main	        = SMS_MSG
table.name.sms.log          = SMS_MSG_LOG

table.name.mms.main         = MMS_MSG
table.name.mms.log          = MMS_MSG_LOG

table.name.msg.phone.main   = MSG_PHONE
table.name.msg.phone.log    = MSG_PHONE_LOG

table.name.duplex.info.main = DUPLEX_INFO

table.name.sms.main.key     = MSGKEY
table.name.mms.main.key     = MSGKEY

sequence.name.sms.main      = SMS_MSG_SEQ
sequence.name.mms.main      = MMS_MSG_SEQ

table.sms.main = CREATE TABLE [COMPARE_TABLE_NAME] \
              ( \
                MSGKEY         bigint     NOT NULL, \
                REQDATE        timestamp without time zone              NOT NULL, \
                SERIALNUM      integer                                          , \
                ID             character varying(16)                            , \
                STATUS         character varying(1)         DEFAULT'1'  NOT NULL, \
                RSLT           character varying(2)         DEFAULT'00'         , \
                TYPE           character varying(1)         DEFAULT'0'  NOT NULL, \
                REPCNT         integer                      DEFAULT 0   NOT NULL, \
                PHONE          character varying(16)        DEFAULT''   NOT NULL, \
                CALLBACK       character varying(16)        DEFAULT ''  NOT NULL, \
                RSLTDATE       timestamp without time zone                      , \
                REPORTDATE     timestamp without time zone                      , \
                MSG            character varying(160)                   NOT NULL, \
                NET            character varying(4)                             , \
                ETC1           character varying(160)                           , \
                ETC2           character varying(160)                           , \
                ETC3           character varying(160)                           , \
                ETC4           character varying(160)                           , \
                ETC5           character varying(160)                           , \
                ETC6           character varying(160)                           , \
                CONSTRAINT PK_[COMPARE_TABLE_NAME] PRIMARY KEY ( MSGKEY ) \
              )

table.sms.log = CREATE TABLE [COMPARE_TABLE_NAME] \
              ( \
                MSGKEY         bigint                                   NOT NULL, \
                REQDATE        timestamp without time zone              NOT NULL, \
                SERIALNUM      integer                                          , \
                ID             character varying(16)                            , \
                STATUS         character varying(1)         DEFAULT'1'  NOT NULL, \
                RSLT           character varying(2)         DEFAULT'00'         , \
                TYPE           character varying(1)         DEFAULT'0'  NOT NULL, \
                REPCNT         integer                      DEFAULT 0   NOT NULL, \
                PHONE          character varying(16)        DEFAULT''   NOT NULL, \
                CALLBACK       character varying(16)        DEFAULT ''  NOT NULL, \
                RSLTDATE       timestamp without time zone                      , \
                REPORTDATE     timestamp without time zone                      , \
                MSG            character varying(160)                   NOT NULL, \
                NET            character varying(4)                             , \
                ETC1           character varying(160)                           , \
                ETC2           character varying(160)                           , \
                ETC3           character varying(160)                           , \
                ETC4           character varying(160)                           , \
                ETC5           character varying(160)                           , \
                ETC6           character varying(160)                             \
              )

table.mms.main = CREATE TABLE [COMPARE_TABLE_NAME] \
              ( \
                MSGKEY              bigint    NOT NULL, \
                SERIALNUM           integer                                         , \
                ID                  character varying(16)                           , \
                STATUS              character varying(2)       DEFAULT'1'   NOT NULL, \
                PHONE               character varying(16)      DEFAULT''    NOT NULL, \
                CALLBACK            character varying(16)      DEFAULT''    NOT NULL, \
                TYPE                character varying(1)       DEFAULT'0'   NOT NULL, \
                REPCNT              integer                    DEFAULT 0    NOT NULL, \
                REQDATE             timestamp without time zone             NOT NULL, \
                SENTDATE            timestamp without time zone                     , \
                RSLTDATE            timestamp without time zone                     , \
                REPORTDATE          timestamp without time zone                     , \
                RSLT                character varying(10)      DEFAULT'00'          , \
                NET                 character varying(10)                           , \
                SUBJECT             character varying(50)                   NOT NULL, \
                MSG                 character varying(4000)                         , \
                FILE_CNT            integer                    DEFAULT 0            , \
                FILE_CNT_REAL       integer                    DEFAULT 0            , \
                FILE_TYPE1          character varying(1)                            , \
                FILE_PATH1          character varying(256)                          , \
                FILE_TYPE2          character varying(1)                            , \
                FILE_PATH2          character varying(256)                          , \
                FILE_TYPE3          character varying(1)                            , \
                FILE_PATH3          character varying(256)                          , \
                FILE_TYPE4          character varying(1)                            , \
                FILE_PATH4          character varying(256)                          , \
                FILE_TYPE5          character varying(1)                            , \
                FILE_PATH5          character varying(256)                          , \
                MMS_FILE_NAME       character varying(256)                          , \
                BAR_TYPE            character varying(2)                            , \
                BAR_MERGE_FILE      integer                                         , \
                BAR_VALUE           character varying(256)                          , \
                BAR_SIZE_WIDTH      integer                                         , \
                BAR_SIZE_HEIGHT     integer                                         , \
                BAR_POSITION_X      integer                                         , \
                BAR_POSITION_Y      integer                                         , \
                BAR_FILE_NAME       character varying(256)                          , \
                ETC1                character varying(160)                          , \
                ETC2                character varying(160)                          , \
                ETC3                character varying(160)                          , \
                ETC4                character varying(160)                          , \
                ETC5                character varying(160)                          , \
                ETC6                character varying(160)                          , \
                CONSTRAINT PK_[COMPARE_TABLE_NAME] PRIMARY KEY ( MSGKEY ) \
              )

table.mms.log = CREATE TABLE [COMPARE_TABLE_NAME] \
              ( \
                MSGKEY              bigint                                  NOT NULL, \
                SERIALNUM           integer                                         , \
                ID                  character varying(16)                           , \
                STATUS              character varying(2)       DEFAULT'1'   NOT NULL, \
                PHONE               character varying(16)      DEFAULT''    NOT NULL, \
                CALLBACK            character varying(16)      DEFAULT''    NOT NULL, \
                TYPE                character varying(1)       DEFAULT'0'   NOT NULL, \
                REPCNT              integer                    DEFAULT 0    NOT NULL, \
                REQDATE             timestamp without time zone             NOT NULL, \
                SENTDATE            timestamp without time zone                     , \
                RSLTDATE            timestamp without time zone                     , \
                REPORTDATE          timestamp without time zone                     , \
                RSLT                character varying(10)      DEFAULT'00'          , \
                NET                 character varying(10)                           , \
                SUBJECT             character varying(50)                   NOT NULL, \
                MSG                 character varying(4000)                         , \
                FILE_CNT            integer                    DEFAULT 0            , \
                FILE_CNT_REAL       integer                    DEFAULT 0            , \
                FILE_TYPE1          character varying(1)                            , \
                FILE_PATH1          character varying(256)                          , \
                FILE_TYPE2          character varying(1)                            , \
                FILE_PATH2          character varying(256)                          , \
                FILE_TYPE3          character varying(1)                            , \
                FILE_PATH3          character varying(256)                          , \
                FILE_TYPE4          character varying(1)                            , \
                FILE_PATH4          character varying(256)                          , \
                FILE_TYPE5          character varying(1)                            , \
                FILE_PATH5          character varying(256)                          , \
                MMS_FILE_NAME       character varying(256)                          , \
                BAR_TYPE            character varying(2)                            , \
                BAR_MERGE_FILE      integer                                         , \
                BAR_VALUE           character varying(256)                          , \
                BAR_SIZE_WIDTH      integer                                         , \
                BAR_SIZE_HEIGHT     integer                                         , \
                BAR_POSITION_X      integer                                         , \
                BAR_POSITION_Y      integer                                         , \
                BAR_FILE_NAME       character varying(256)                          , \
                ETC1                character varying(160)                          , \
                ETC2                character varying(160)                          , \
                ETC3                character varying(160)                          , \
                ETC4                character varying(160)                          , \
                ETC5                character varying(160)                          , \
                ETC6                character varying(160)                            \
              )

table.msg.phone.main = CREATE TABLE [COMPARE_TABLE_NAME] \
                  ( \
                    MSGTYPE           character varying(1)    DEFAULT 'S'    NOT NULL, \
                    MSGKEY            integer                                NOT NULL, \
                    PHONE             character varying(16)                  NOT NULL, \
                    CALLBACK          character varying(16)                  NOT NULL, \
                    STATUS            character varying(2)     DEFAULT'1'    NOT NULL, \
                    RSLTDATE          timestamp without time zone                    , \
                    REPORTDATE        timestamp without time zone                    , \
                    RSLT              character varying(10)    DEFAULT'00'           , \
                    NET               character varying(10)                          , \
                    REPLACE_CNT       integer      DEFAULT 0      NOT NULL           , \
                    REPLACE_MSG       character varying(256)                         , \
                    CONSTRAINT PK_[COMPARE_TABLE_NAME] PRIMARY KEY ( MSGTYPE, MSGKEY, PHONE ) \
                  )

table.msg.phone.log = CREATE TABLE [COMPARE_TABLE_NAME] \
                  ( \
                    MSGTYPE           character varying(1)    DEFAULT 'S'    NOT NULL, \
                    MSGKEY            integer                                NOT NULL, \
                    PHONE             character varying(16)                  NOT NULL, \
                    CALLBACK          character varying(16)                  NOT NULL, \
                    STATUS            character varying(2)     DEFAULT'1'    NOT NULL, \
                    RSLTDATE          timestamp without time zone                    , \
                    REPORTDATE        timestamp without time zone                    , \
                    RSLT              character varying(10)    DEFAULT'00'           , \
                    NET               character varying(10)                          , \
                    REPLACE_CNT       integer      DEFAULT 0      NOT NULL           , \
                    REPLACE_MSG       character varying(256)                           \
                  )

table.duplex.info.main = CREATE TABLE [COMPARE_TABLE_NAME] \
                  ( \
                    INFO_SEQ                integer                                  NOT NULL, \
                    INFO_MASTER_ID          character varying(10)  DEFAULT 'MASTER'  NOT NULL, \
                    INFO_MASTER_ADDRESS     character varying(50)                            , \
                    INFO_MASTER_NAME        character varying(50)                            , \
                    INFO_MASTER_ALIVE       character varying(1)   DEFAULT 'N'       NOT NULL, \
                    INFO_MASTER_ALIVEDATE   timestamp without time zone                      , \
                    INFO_MASTER_DIEDATE     timestamp without time zone                      , \
                    INFO_SLAVE_ID           character varying(10)  DEFAULT 'SLAVE'   NOT NULL, \
                    INFO_SLAVE_ADDRESS      character varying(50)                            , \
                    INFO_SLAVE_NAME         character varying(50)                            , \
                    INFO_SLAVE_ALIVE        character varying(1)   DEFAULT 'N'       NOT NULL, \
                    INFO_SLAVE_ALIVEDATE    timestamp without time zone                      , \
                    INFO_SLAVE_DIEDATE      timestamp without time zone                      , \
                    CONSTRAINT PK_[COMPARE_TABLE_NAME] PRIMARY KEY ( INFO_SEQ )                \
                  )

table.main.sequence.create = CREATE SEQUENCE [COMPARE_TABLE_NAME] INCREMENT BY 1 START WITH 1
table.main.sequence.select = SELECT c.relname FROM pg_class c WHERE c.relkind = 'S' and relname='[COMPARE_TABLE_NAME]'

table.sms.main.index1 = CREATE INDEX IDX_[COMPARE_TABLE_NAME]_1 ON [COMPARE_TABLE_NAME] ( STATUS, REQDATE )
table.sms.main.index2 = CREATE INDEX IDX_[COMPARE_TABLE_NAME]_2 ON [COMPARE_TABLE_NAME] ( PHONE )

table.mms.main.index1 = CREATE INDEX IDX_[COMPARE_TABLE_NAME]_1 ON [COMPARE_TABLE_NAME] ( STATUS, REQDATE )
table.mms.main.index2 = CREATE INDEX IDX_[COMPARE_TABLE_NAME]_2 ON [COMPARE_TABLE_NAME] ( PHONE )

table.msg.phone.main.index1 =

table.sms.log.index1 = CREATE INDEX IDX_[COMPARE_TABLE_NAME]_1 ON [COMPARE_TABLE_NAME] ( STATUS, REQDATE )
table.sms.log.index2 = CREATE INDEX IDX_[COMPARE_TABLE_NAME]_2 ON [COMPARE_TABLE_NAME] ( PHONE )

table.mms.log.index1 = CREATE INDEX IDX_[COMPARE_TABLE_NAME]_1 ON [COMPARE_TABLE_NAME] ( STATUS, REQDATE )
table.mms.log.index2 = CREATE INDEX IDX_[COMPARE_TABLE_NAME]_2 ON [COMPARE_TABLE_NAME] ( PHONE )

table.msg.phone.log.index1 =

table.name.check = SELECT * FROM pg_tables where upper(tablename) = '[COMPARE_TABLE_NAME]'

sms.send.data = SELECT \
                MSGKEY    as TR_NUM,       \
                REQDATE   as TR_SENDDATE,  \
                SERIALNUM as TR_SERIALNUM, \
                ID        as TR_ID,        \
                STATUS    as TR_SENDSTAT,  \
                TYPE      as TR_MSGTYPE,   \
                REPCNT    as TR_REPCNT,    \
                PHONE     as TR_PHONE,     \
                CALLBACK  as TR_CALLBACK,  \
                MSG       as TR_MSG        \
              FROM [COMPARE_TABLE_NAME]    \
              WHERE STATUS = '[:TR_SENDSTAT]' \
                      AND REQDATE <= CURRENT_TIMESTAMP \
                      AND REQDATE >= CURRENT_TIMESTAMP - interval '[:INTERVAL] hours' \
                      [:WHERE_MULTI] \
              LIMIT 500

mms.send.data = SELECT \
                MSGKEY, \
                SERIALNUM, \
                ID, \
                STATUS, \
                PHONE, \
                CALLBACK, \
                TYPE, \
                REPCNT, \
                REQDATE, \
                SUBJECT, \
                MSG, \
                FILE_CNT, \
                FILE_CNT_REAL, \
                FILE_TYPE1, \
                FILE_PATH1, \
                FILE_TYPE2, \
                FILE_PATH2, \
                FILE_TYPE3, \
                FILE_PATH3, \
                FILE_TYPE4, \
                FILE_PATH4, \
                FILE_TYPE5, \
                FILE_PATH5, \
                BAR_TYPE, \
                BAR_MERGE_FILE, \
                BAR_VALUE, \
                BAR_SIZE_WIDTH, \
                BAR_SIZE_HEIGHT, \
                BAR_POSITION_X, \
                BAR_POSITION_Y, \
                BAR_FILE_NAME \
              FROM [COMPARE_TABLE_NAME] \
              WHERE STATUS = '[:STATUS]' \
                      AND REQDATE <= CURRENT_TIMESTAMP \
                      AND REQDATE >= CURRENT_TIMESTAMP - interval '[:INTERVAL] hours' \
                      [:WHERE_MULTI] \
              LIMIT 500

msg.phone.send.data = SELECT \
                      MSGTYPE, \
                      MSGKEY, \
                      PHONE, \
                      CALLBACK, \
                      STATUS, \
                      RSLTDATE, \
                      REPORTDATE, \
                      RSLT, \
                      NET, \
                      REPLACE_CNT, \
                      REPLACE_MSG \
                    FROM [COMPARE_TABLE_NAME] \
                    WHERE MSGTYPE = '[:MSGTYPE]' AND MSGKEY = [:MSGKEY]

sms.send.data.update = UPDATE [COMPARE_TABLE_NAME] \
                    SET STATUS = '[:TR_SENDSTAT]', \
                    RSLT = '[:TR_RSLTSTAT]' \
                    WHERE MSGKEY = [:TR_NUM]

mms.send.data.update = UPDATE [COMPARE_TABLE_NAME] \
                    SET STATUS = '[:STATUS]', \
                    SENTDATE = CURRENT_TIMESTAMP, \
                    RSLT = '[:RSLT]' \
                    WHERE MSGKEY = [:MSGKEY]

msg.phone.send.data.update = UPDATE [COMPARE_TABLE_NAME] \
                          SET STATUS = '[:STATUS]', \
                          RSLT = '[:RSLT]' \
                          WHERE MSGTYPE = '[:MSGTYPE]' AND MSGKEY = [:MSGKEY]

sms.recev.data.update = UPDATE [COMPARE_TABLE_NAME] \
                    SET STATUS = '[:TR_SENDSTAT]', \
                    RSLTDATE = TO_DATE( [:TR_RSLTDATE], 'YYYYMMDDHH24MISS' ), \
                    REPORTDATE = CURRENT_TIMESTAMP, \
                    RSLT = '[:TR_RSLTSTAT]', \
                    NET = '[:TR_NET]' \
                    WHERE MSGKEY = [:TR_NUM]

mms.recev.data.update = UPDATE [COMPARE_TABLE_NAME] \
                    SET STATUS = '[:STATUS]', \
                    RSLTDATE = TO_DATE( [:RSLTDATE], 'YYYYMMDDHH24MISS' ), \
                    REPORTDATE = CURRENT_TIMESTAMP, \
                    RSLT = '[:RSLT]', \
                    NET = '[:NET]' \
                    WHERE MSGKEY = [:MSGKEY]

msg.phone.recev.data.update = UPDATE [COMPARE_TABLE_NAME] \
                          SET STATUS = '[:STATUS]', \
                          RSLTDATE = TO_DATE( [:RSLTDATE], 'YYYYMMDDHH24MISS' ), \
                          REPORTDATE = CURRENT_TIMESTAMP, \
                          RSLT = '[:RSLT]', \
                          NET = '[:NET]' \
                          WHERE MSGTYPE = '[:MSGTYPE]' AND MSGKEY = [:MSGKEY] AND PHONE = '[:PHONE]'

sms.recev.data.update2 = UPDATE [COMPARE_TABLE_NAME] \
                      SET REPCNT = REPCNT + 1 \
                      WHERE MSGKEY = [:TR_NUM]

sms.recev.data.update3 = UPDATE [COMPARE_TABLE_NAME] \
                      SET STATUS = '[:TR_SENDSTAT]', \
                      REPORTDATE = CURRENT_TIMESTAMP \
                      WHERE REPCNT = PHONE

mms.recev.data.update2 = UPDATE [COMPARE_TABLE_NAME] \
                      SET REPCNT = REPCNT + 1 \
                      WHERE MSGKEY = [:MSGKEY]

mms.recev.data.update3 = UPDATE [COMPARE_TABLE_NAME] \
                      SET STATUS = '[:STATUS]', \
                      REPORTDATE = CURRENT_TIMESTAMP \
                      WHERE REPCNT = PHONE

sms.log.data.batch.insert = INSERT INTO [COMPARE_LOG_TABLE_NAME] \
                      ( \
                        MSGKEY         ,\
                        REQDATE        ,\
                        SERIALNUM      ,\
                        ID             ,\
                        STATUS         ,\
                        RSLT           ,\
                        TYPE           ,\
                        REPCNT         ,\
                        PHONE          ,\
                        CALLBACK       ,\
                        RSLTDATE       ,\
                        REPORTDATE     ,\
                        MSG            ,\
                        NET            ,\
                        ETC1           ,\
                        ETC2           ,\
                        ETC3           ,\
                        ETC4           ,\
                        ETC5           ,\
                        ETC6            \
                      ) \
                      SELECT \
                        MSGKEY         ,\
                        REQDATE        ,\
                        SERIALNUM      ,\
                        ID             ,\
                        STATUS         ,\
                        RSLT           ,\
                        TYPE           ,\
                        REPCNT         ,\
                        PHONE          ,\
                        CALLBACK       ,\
                        RSLTDATE       ,\
                        REPORTDATE     ,\
                        MSG            ,\
                        NET            ,\
                        ETC1           ,\
                        ETC2           ,\
                        ETC3           ,\
                        ETC4           ,\
                        ETC5           ,\
                        ETC6            \
                      FROM [COMPARE_TABLE_NAME] \
                      WHERE STATUS = '[:TR_SENDSTAT]' \
                      AND REQDATE > TO_DATE(  '[:TR_FROMDATE]','YYYYMMDD') \
                      AND REQDATE < TO_DATE(  '[:TR_TODATE]','YYYYMMDD') \
                      AND REPORTDATE <= TO_DATE( '[:TR_SENDDATE]','YYYYMMDDHH24MISS') - 1/24/60

sms.log.data.batch.delete = DELETE FROM [COMPARE_TABLE_NAME] \
                             WHERE STATUS = '[:TR_SENDSTAT]' \
                               AND REQDATE > TO_DATE(  '[:TR_FROMDATE]','YYYYMMDD') \
                               AND REQDATE < TO_DATE(  '[:TR_TODATE]','YYYYMMDD') \
                               AND REPORTDATE <= TO_DATE( '[:TR_SENDDATE]','YYYYMMDDHH24MISS') - 1/24/60

mms.log.data.batch.insert = INSERT INTO [COMPARE_LOG_TABLE_NAME] \
                      ( \
                        MSGKEY, \
                        SERIALNUM, \
                        ID, \
                        STATUS, \
                        PHONE, \
                        CALLBACK, \
                        TYPE, \
                        REPCNT, \
                        REQDATE, \
                        SENTDATE, \
                        RSLTDATE, \
                        REPORTDATE, \
                        RSLT, \
                        NET, \
                        SUBJECT, \
                        MSG, \
                        FILE_CNT, \
                        FILE_CNT_REAL, \
                        FILE_TYPE1, \
                        FILE_PATH1, \
                        FILE_TYPE2, \
                        FILE_PATH2, \
                        FILE_TYPE3, \
                        FILE_PATH3, \
                        FILE_TYPE4, \
                        FILE_PATH4, \
                        FILE_TYPE5, \
                        FILE_PATH5, \
                        MMS_FILE_NAME, \
                        BAR_TYPE, \
                        BAR_MERGE_FILE, \
                        BAR_VALUE, \
                        BAR_SIZE_WIDTH, \
                        BAR_SIZE_HEIGHT, \
                        BAR_POSITION_X, \
                        BAR_POSITION_Y, \
                        BAR_FILE_NAME, \
                        ETC1, \
                        ETC2, \
                        ETC3, \
                        ETC4, \
                        ETC5, \
                        ETC6 \
                      ) \
                      SELECT \
                        MSGKEY, \
                        SERIALNUM, \
                        ID, \
                        STATUS, \
                        PHONE, \
                        CALLBACK, \
                        TYPE, \
                        REPCNT, \
                        REQDATE, \
                        SENTDATE, \
                        RSLTDATE, \
                        REPORTDATE, \
                        RSLT, \
                        NET, \
                        SUBJECT, \
                        MSG, \
                        FILE_CNT, \
                        FILE_CNT_REAL, \
                        FILE_TYPE1, \
                        FILE_PATH1, \
                        FILE_TYPE2, \
                        FILE_PATH2, \
                        FILE_TYPE3, \
                        FILE_PATH3, \
                        FILE_TYPE4, \
                        FILE_PATH4, \
                        FILE_TYPE5, \
                        FILE_PATH5, \
                        MMS_FILE_NAME, \
                        BAR_TYPE, \
                        BAR_MERGE_FILE, \
                        BAR_VALUE, \
                        BAR_SIZE_WIDTH, \
                        BAR_SIZE_HEIGHT, \
                        BAR_POSITION_X, \
                        BAR_POSITION_Y, \
                        BAR_FILE_NAME, \
                        ETC1, \
                        ETC2, \
                        ETC3, \
                        ETC4, \
                        ETC5, \
                        ETC6 \
                      FROM [COMPARE_TABLE_NAME] \
                      WHERE STATUS = '[:STATUS]' \
                      AND REQDATE > TO_DATE(  '[:FROMDATE]','YYYYMMDD') \
                      AND REQDATE < TO_DATE(  '[:TODATE]','YYYYMMDD') \
                      AND REPORTDATE <= TO_DATE( '[:REQDATE]','YYYYMMDDHH24MISS') - 1/24/60

mms.log.data.batch.delete = DELETE FROM [COMPARE_TABLE_NAME] \
                      WHERE STATUS = '[:STATUS]' \
                      AND REQDATE > TO_DATE(  '[:FROMDATE]','YYYYMMDD') \
                      AND REQDATE < TO_DATE(  '[:TODATE]','YYYYMMDD') \
                      AND REPORTDATE <= TO_DATE( '[:REQDATE]','YYYYMMDDHH24MISS') - 1/24/60

msg.phone.log.data.batch.insert = INSERT INTO [COMPARE_LOG_TABLE_NAME] \
                            ( \
                              MSGTYPE, \
                              MSGKEY, \
                              PHONE, \
                              CALLBACK, \
                              STATUS, \
                              RSLTDATE, \
                              REPORTDATE, \
                              RSLT, \
                              NET, \
                              REPLACE_CNT, \
                              REPLACE_MSG \
                            ) \
                            SELECT \
                              MSGTYPE, \
                              MSGKEY, \
                              PHONE, \
                              CALLBACK, \
                              STATUS, \
                              RSLTDATE, \
                              REPORTDATE, \
                              RSLT, \
                              NET, \
                              REPLACE_CNT, \
                              REPLACE_MSG \
                            FROM [COMPARE_TABLE_NAME] \
                            WHERE STATUS = '[:STATUS]'

msg.phone.log.data.batch.delete = DELETE FROM [COMPARE_TABLE_NAME] \
                            WHERE STATUS = '[:STATUS]'

sms.log.data.real.select = SELECT \
                        MSGKEY  as TR_NUM, \
                        TO_CHAR( REQDATE, 'YYYYMMDDHH24MISS' ) AS TR_SENDDATE \
                      FROM [COMPARE_TABLE_NAME] \
                      WHERE STATUS = '[:TR_SENDSTAT]' \
                      LIMIT 500

sms.log.data.real.insert = INSERT INTO [COMPARE_LOG_TABLE_NAME] \
                      ( \
                        MSGKEY         ,\
                        REQDATE        ,\
                        SERIALNUM      ,\
                        ID             ,\
                        STATUS         ,\
                        RSLT           ,\
                        TYPE           ,\
                        REPCNT         ,\
                        PHONE          ,\
                        CALLBACK       ,\
                        RSLTDATE       ,\
                        REPORTDATE     ,\
                        MSG            ,\
                        NET            ,\
                        ETC1           ,\
                        ETC2           ,\
                        ETC3           ,\
                        ETC4           ,\
                        ETC5           ,\
                        ETC6            \
                      ) \
                      SELECT \
                        MSGKEY         ,\
                        REQDATE        ,\
                        SERIALNUM      ,\
                        ID             ,\
                        STATUS         ,\
                        RSLT           ,\
                        TYPE           ,\
                        REPCNT         ,\
                        PHONE          ,\
                        CALLBACK       ,\
                        RSLTDATE       ,\
                        REPORTDATE     ,\
                        MSG            ,\
                        NET            ,\
                        ETC1           ,\
                        ETC2           ,\
                        ETC3           ,\
                        ETC4           ,\
                        ETC5           ,\
                        ETC6            \
                      FROM [COMPARE_TABLE_NAME] \
                      WHERE MSGKEY = [:TR_NUM]

sms.log.data.real.delete = DELETE FROM [COMPARE_TABLE_NAME] \
                      WHERE MSGKEY = [:TR_NUM]

mms.log.data.real.select = SELECT \
                        MSGKEY, \
                        TO_CHAR( REQDATE, 'YYYYMMDDHH24MISS' ) AS REQDATE \
                      FROM [COMPARE_TABLE_NAME] \
                      WHERE STATUS = '[:STATUS]' \
                      LIMIT 500

mms.log.data.real.insert = INSERT INTO [COMPARE_LOG_TABLE_NAME] \
                      ( \
                        MSGKEY, \
                        SERIALNUM, \
                        ID, \
                        STATUS, \
                        PHONE, \
                        CALLBACK, \
                        TYPE, \
                        REPCNT, \
                        REQDATE, \
                        SENTDATE, \
                        RSLTDATE, \
                        REPORTDATE, \
                        RSLT, \
                        NET, \
                        SUBJECT, \
                        MSG, \
                        FILE_CNT, \
                        FILE_CNT_REAL, \
                        FILE_TYPE1, \
                        FILE_PATH1, \
                        FILE_TYPE2, \
                        FILE_PATH2, \
                        FILE_TYPE3, \
                        FILE_PATH3, \
                        FILE_TYPE4, \
                        FILE_PATH4, \
                        FILE_TYPE5, \
                        FILE_PATH5, \
                        MMS_FILE_NAME, \
                        BAR_TYPE, \
                        BAR_MERGE_FILE, \
                        BAR_VALUE, \
                        BAR_SIZE_WIDTH, \
                        BAR_SIZE_HEIGHT, \
                        BAR_POSITION_X, \
                        BAR_POSITION_Y, \
                        BAR_FILE_NAME, \
                        ETC1, \
                        ETC2, \
                        ETC3, \
                        ETC4, \
                        ETC5, \
                        ETC6 \
                      ) \
                      SELECT \
                        MSGKEY, \
                        SERIALNUM, \
                        ID, \
                        STATUS, \
                        PHONE, \
                        CALLBACK, \
                        TYPE, \
                        REPCNT, \
                        REQDATE, \
                        SENTDATE, \
                        RSLTDATE, \
                        REPORTDATE, \
                        RSLT, \
                        NET, \
                        SUBJECT, \
                        MSG, \
                        FILE_CNT, \
                        FILE_CNT_REAL, \
                        FILE_TYPE1, \
                        FILE_PATH1, \
                        FILE_TYPE2, \
                        FILE_PATH2, \
                        FILE_TYPE3, \
                        FILE_PATH3, \
                        FILE_TYPE4, \
                        FILE_PATH4, \
                        FILE_TYPE5, \
                        FILE_PATH5, \
                        MMS_FILE_NAME, \
                        BAR_TYPE, \
                        BAR_MERGE_FILE, \
                        BAR_VALUE, \
                        BAR_SIZE_WIDTH, \
                        BAR_SIZE_HEIGHT, \
                        BAR_POSITION_X, \
                        BAR_POSITION_Y, \
                        BAR_FILE_NAME, \
                        ETC1, \
                        ETC2, \
                        ETC3, \
                        ETC4, \
                        ETC5, \
                        ETC6 \
                      FROM [COMPARE_TABLE_NAME] \
                      WHERE MSGKEY = [:MSGKEY]

mms.log.data.real.delete = DELETE FROM [COMPARE_TABLE_NAME] \
                      WHERE MSGKEY = [:MSGKEY]

msg.phone.log.data.real.select = SELECT \
                            MSGTYPE, \
                            MSGKEY, \
                            PHONE, \
                            CALLBACK, \
                            STATUS, \
                            RSLTDATE, \
                            REPORTDATE, \
                            RSLT, \
                            NET, \
                            REPLACE_CNT, \
                            REPLACE_MSG \
                          FROM [COMPARE_TABLE_NAME] \
                          WHERE STATUS = '[:STATUS]' \
                          LIMIT 500

msg.phone.log.data.real.insert = INSERT INTO [COMPARE_LOG_TABLE_NAME] \
                          ( \
                            MSGTYPE, \
                            MSGKEY, \
                            PHONE, \
                            CALLBACK, \
                            STATUS, \
                            RSLTDATE, \
                            REPORTDATE, \
                            RSLT, \
                            NET, \
                            REPLACE_CNT, \
                            REPLACE_MSG \
                          ) \
                          SELECT \
                            MSGTYPE, \
                            MSGKEY, \
                            PHONE, \
                            CALLBACK, \
                            STATUS, \
                            RSLTDATE, \
                            REPORTDATE, \
                            RSLT, \
                            NET, \
                            REPLACE_CNT, \
                            REPLACE_MSG \
                          FROM [COMPARE_TABLE_NAME] \
                          WHERE MSGTYPE = '[:MSGTYPE]' AND MSGKEY = [:MSGKEY] AND PHONE = '[:PHONE]'

msg.phone.log.data.real.delete = DELETE FROM [COMPARE_TABLE_NAME] \
                          WHERE MSGTYPE = '[:MSGTYPE]' AND MSGKEY = [:MSGKEY] AND PHONE = '[:PHONE]'

sms.log.data.timeout.update = UPDATE [COMPARE_TABLE_NAME] SET STATUS ='[:TR_RSLTSTAT]' , RSLT ='[:TR_TIMEOUTCODE]' , REPORTDATE=CURRENT_TIMESTAMP, NET='ETC', RSLTDATE=CURRENT_TIMESTAMP \
                      WHERE STATUS = '[:TR_SENDSTAT]' AND REQDATE <= TO_DATE( '[:TR_SENDDATE]','YYYYMMDDHH24MISS')

mms.log.data.timeout.update = UPDATE [COMPARE_TABLE_NAME] SET STATUS ='[:TR_RSLTSTAT]' , RSLT ='[:TR_TIMEOUTCODE]' , REPORTDATE=CURRENT_TIMESTAMP, NET='ETC', RSLTDATE=CURRENT_TIMESTAMP \
                      WHERE STATUS = '[:TR_SENDSTAT]' AND REQDATE <= TO_DATE( '[:TR_SENDDATE]','YYYYMMDDHH24MISS')
